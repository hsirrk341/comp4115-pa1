-- MySQL dump 10.13  Distrib 5.6.22, for Win64 (x86_64)
--
-- Host: localhost    Database: us_states
-- ------------------------------------------------------
-- Server version	5.6.22-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `name` varchar(40) DEFAULT NULL,
  `population` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `temperature` int(11) DEFAULT NULL,
  `location` enum('west','east','north','south') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES ('Alabama',8383,1,233,'south'),('Alaska',10000,2,40,'south'),('arizona',9000,3,39,'south'),('califonia',7000,4,29,'west'),('Delaware',900,5,29,'north'),('Florida',300,6,48,'east'),('Illinois',3300,7,438,'east'),('arkansas',8700,8,38,'west'),('connecticut',3300,9,438,'east'),('kansas',2300,10,55,'north'),('colarado',8700,11,45,'north'),('Tennessee',3245,12,78,'south'),('texas',32245,13,798,'south'),('south carolina',2384903,14,38,'west'),('kentucky',1225,15,78,'east'),('oregon',78555,16,87,'west'),('oklahoma',27854,17,62,'north'),('puerto rico',8949,18,44,'west'),('lowa',27845,19,54,'south'),('mississippi',792379,20,457,'east'),('utah',17979,21,457,'north'),('nevada',792279,22,457,'east'),('new mexico',37979,23,457,'west'),('nebraska',793279,24,457,'east'),('north virginia',7979,25,457,'east'),('idaho',127979,26,123,'west'),('hawaii',792379,27,43,'east'),('maine',7979,28,457,'west'),('new hampshire',37979,29,76,'east'),('montana',237979,30,56,'south'),('north dakota',17979,31,43,'east'),('south dokata',27979,32,457,'east'),('vermont',17979,33,43,'east'),('florida',79179,34,34,'north'),('new york',792379,35,32,'east'),('illinois',37979,36,23,'south'),('pennsylvania',57979,37,23,'west'),('ohio',27979,38,43,'east'),('georgia',27979,39,77,'south'),('north carolina',7979,40,88,'north'),('new jersey',37979,41,66,'west'),('virginia',795579,42,55,'south'),('washington',797759,43,33,'north'),('massachusetts',73979,44,32,'west'),('indiana',794579,45,23,'east'),('missouri',787979,46,32,'east'),('colorado',97979,47,23,'west'),('michigan',255,48,58,'north'),('xyz',13,49,54,'west'),('uvw',32,50,20,'west'),('pqr',23,51,24,'east');
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp`
--

DROP TABLE IF EXISTS `temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp` (
  `attr` enum('big','small','medium') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp`
--

LOCK TABLES `temp` WRITE;
/*!40000 ALTER TABLE `temp` DISABLE KEYS */;
INSERT INTO `temp` VALUES ('small');
/*!40000 ALTER TABLE `temp` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-12  1:42:02
